#include <iostream>
#include "GameManager.h"
using namespace std;

int main()
{
    GameManager manager;
    manager.Play();
    return 0;
}